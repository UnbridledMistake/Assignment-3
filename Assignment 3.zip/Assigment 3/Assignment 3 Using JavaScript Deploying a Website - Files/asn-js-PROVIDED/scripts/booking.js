/********* create variables *********/
// useful variables might be: the cost per day, the number of days selected, and elements on the screen that will be clicked or will need to be modified. 
// Do any of these variables need to be initialized when the page is loaded? 
// When do they need to be reset or updated?



var daysSelected = 0;
var dayRate = 35;
var totalCost = 0;

/********* colour change days of week *********/
// when the day buttons are clicked, we will apply the "clicked" class to that element, and update any other relevant variables. Then, we can recalculate the total cost.
// added challenge: don't update the dayCounter if the same day is clicked more than once. hint: .classList.contains() might be helpful here!


function calculate() {
    totalCost = daysSelected * dayRate;
    console.log("Total cost:", totalCost);
    console.log("Days: ", daysSelected, "Rate: ", dayRate);
}

document.getElementById("monday").addEventListener("click", function () {

    let monday = document.getElementById("monday");
    monday.classList.toggle("clicked");

    if (monday.classList.contains("clicked")) {
        daysSelected++;

    } else {
        daysSelected--;
    }


    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;



});

document.getElementById("tuesday").addEventListener("click", function () {

    let tuesday = document.getElementById("tuesday");
    tuesday.classList.toggle("clicked");

    if (tuesday.classList.contains("clicked")) {
        daysSelected++;
    } else {
        daysSelected--;

    }

    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;
});

document.getElementById("wednesday").addEventListener("click", function () {

    let wednesday = document.getElementById("wednesday");
    wednesday.classList.toggle("clicked");

    if (wednesday.classList.contains("clicked")) {
        daysSelected++;
        calculate;
    } else {
        daysSelected--;
    }



    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;


});

document.getElementById("thursday").addEventListener("click", function () {

    let thursday = document.getElementById("thursday");
    thursday.classList.toggle("clicked");

    if (thursday.classList.contains("clicked")) {
        daysSelected++;
        calculate;
    } else {
        daysSelected--;
    }


    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;


});

document.getElementById("friday").addEventListener("click", function () {

    let friday = document.getElementById("friday");
    friday.classList.toggle("clicked");

    if (friday.classList.contains("clicked")) {
        daysSelected++;
        calculate;
    } else {
        daysSelected--;
    }



    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;

});



/********* clear days *********/
// when the clear-button is clicked, the "clicked" class is removed from all days, any other relevant variables are reset, and the calculated cost is set to 0.

document.getElementById("clear-button").addEventListener("click", function () {

    monday.classList.remove("clicked");
    tuesday.classList.remove("clicked");
    wednesday.classList.remove("clicked");
    thursday.classList.remove("clicked");
    friday.classList.remove("clicked");

    daysSelected = 0;


    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;

});



/********* change rate *********/
// when the half-day button is clicked, set the daily rate to $20, add the "clicked" class to the "half" element, remove it from the "full" element, and recalculate the total cost.


document.getElementById("half").addEventListener("click", function () {



    let fullButton = document.getElementById("full");

    let halfButton = document.getElementById("half");
    halfButton.classList.toggle("clicked");

    if (halfButton.classList.contains("clicked")) {
        dayRate = 20;
        calculate;
        fullButton.classList.remove("clicked");
    }


    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;


});



// when the full-day button is clicked, the daily rate is set back to $35, the clicked class is added to "full" and removed from "half", and the total cost is recalculated.

var fullButton = document.getElementById("full");
fullButton.classList.toggle("clicked");

document.getElementById("full").addEventListener("click", function () {



    let halfButton = document.getElementById("half");

    var fullButton = document.getElementById("full");
    fullButton.classList.toggle("clicked");

    if (fullButton.classList.contains("clicked")) {
        dayRate = 35;
        calculate;
        halfButton.classList.remove("clicked");
    }





    calculate();
    costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;

});


/********* calculate *********/
// when a calculation is needed, set the innerHTML of the calculated-cost element to the appropriate value




// function calculate(){
//     totalCost = dayRate * daysSelected 
// }

// console.log("Day Rate: ", dayRate, "Total Days", daysSelected);

costLabel = document.getElementById("calculated-cost").innerHTML = totalCost;

